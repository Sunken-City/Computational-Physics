int sweep(double (*func)(double x),double xstart,double xstop,double xinc);
int sweep2(double (*func)(double x,double y),double xstart,double xstop,double xinc,double ystart,double ystop,double yinc);
