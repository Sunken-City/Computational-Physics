void random_seed(unsigned long int seed);
double random_gen(void);
double random_normal_gen(double mu,double sigma);
