int trapezoidal(double (*func)(double x),double xstart,double xstop,double xinc);
int simpson(double (*func)(double x),double xstart,double xstop,double xinc);
