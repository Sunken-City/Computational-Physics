struct point2d {
  double x;
  double y;
};
int read_data_file(char *file_name,struct point2d **data_ptr);
