int fitsine(int n,double *a,struct point2d *sample);
