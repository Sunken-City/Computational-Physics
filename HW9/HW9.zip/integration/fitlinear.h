int fitlinear(int n,double *a0ptr,double *a1ptr,struct point2d *sample);
